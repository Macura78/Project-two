#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

// Function to display report without monthly deposits
void displayWithoutMonthlyDeposits(double initialInvestment, double annualInterest, int years) {
    double yearEndBalance = initialInvestment;
    double interestEarned;

    cout << "\n  Balance and Interest Without Additional Monthly Deposits\n";
    cout << "===========================================================\n";
    cout << "  Year\t\tYear End Balance\tInterest Earned\n";

    for (int i = 1; i <= years; ++i) {
        interestEarned = yearEndBalance * (annualInterest / 100);
        yearEndBalance += interestEarned;
        cout << "   " << i << "\t\t$" << fixed << setprecision(2) << yearEndBalance 
             << "\t\t$" << interestEarned << endl;
    }
}

// Function to display report with monthly deposits
void displayWithMonthlyDeposits(double initialInvestment, double monthlyDeposit, double annualInterest, int years) {
    double balance = initialInvestment;
    double monthlyInterestRate = annualInterest / 100 / 12;
    double interestEarned, totalInterest;

    cout << "\n  Balance and Interest With Additional Monthly Deposits\n";
    cout << "========================================================\n";
    cout << "  Year\t\tYear End Balance\tInterest Earned\n";

    for (int i = 1; i <= years; ++i) {
        totalInterest = 0;
        for (int j = 0; j < 12; ++j) {
            balance += monthlyDeposit;
            interestEarned = balance * monthlyInterestRate;
            totalInterest += interestEarned;
            balance += interestEarned;
        }
        cout << "   " << i << "\t\t$" << fixed << setprecision(2) << balance 
             << "\t\t$" << totalInterest << endl;
    }
}

int main() {
    double initialInvestment, monthlyDeposit, annualInterest;
    int years;
    char userChoice;

    do {
        cout << "====================================\n";
        cout << "   Airgead Banking Investment App   \n";
        cout << "====================================\n";

        // User inputs
        cout << "Enter Initial Investment Amount: $";
        cin >> initialInvestment;

        cout << "Enter Monthly Deposit: $";
        cin >> monthlyDeposit;

        cout << "Enter Annual Interest Rate (percent): ";
        cin >> annualInterest;

        cout << "Enter Number of Years: ";
        cin >> years;

        cout << "\nPress any key to continue to reports...\n";
        cin.ignore();
        cin.get();

        // Display reports
        displayWithoutMonthlyDeposits(initialInvestment, annualInterest, years);
        displayWithMonthlyDeposits(initialInvestment, monthlyDeposit, annualInterest, years);

        // Ask to repeat
        cout << "\nWould you like to try different values? (y/n): ";
        cin >> userChoice;

    } while (tolower(userChoice) == 'y');

    cout << "\nThank you for using the Airgead Banking App!\n";
    return 0;
}
